/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for the iOS & tvOS application delegate.
*/

#import <UIKit/UIKit.h>

@interface AAPLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
