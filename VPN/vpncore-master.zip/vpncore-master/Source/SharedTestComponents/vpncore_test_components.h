//
//  vpncore_test_components_macos.h
//  vpncore-test-components-macos
//
//  Created by Robert Patchett on 06.06.19.
//  Copyright © 2019 Proton Technologies AG. All rights reserved.
//

@import Foundation;

//! Project version number for vpncore_test_components_macos.
FOUNDATION_EXPORT double vpncore_test_components_iosVersionNumber;

//! Project version string for vpncore_test_components_macos.
FOUNDATION_EXPORT const unsigned char vpncore_test_components_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <vpncore_test_components_macos/PublicHeader.h>


