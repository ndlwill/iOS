//
//  PacketTunnelProvider.swift
//  ProtonVPN - Created on 29.07.19.
//
//
//  Copyright (c) 2019 Proton Technologies AG
//
//  See LICENSE for up to date license information.

import TunnelKit

class PacketTunnelProvider: OpenVPNTunnelProvider {
}
