Templates iOS application 
===

To use a template: copy folder  with template  (for example MVVM folder without .extension)
and paste it inside path  ~/Library/Developer/Xcode/Templates/ 
You can locate this folder by using Finder (Go to folder...) Shift+Command+G
Then when creating, New File... , Scroll down to section with Tempalte name that you added. 
