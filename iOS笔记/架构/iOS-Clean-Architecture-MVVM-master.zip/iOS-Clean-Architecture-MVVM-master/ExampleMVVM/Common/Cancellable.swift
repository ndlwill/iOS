import Foundation

protocol Cancellable {
    func cancel()
}
