/*
	Copyright (C) 2016 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	This file exposes utility Objective-C functions to Swift.
*/

@import Foundation;

#import "ServerUtils.h"
