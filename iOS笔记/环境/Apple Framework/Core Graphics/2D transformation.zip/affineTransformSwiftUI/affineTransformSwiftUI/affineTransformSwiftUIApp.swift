//
//  affineTransformSwiftUIApp.swift
//  affineTransformSwiftUI
//
//  Created by Kyryl Horbushko on 12/8/20.
//

import SwiftUI

@main
struct affineTransformSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
