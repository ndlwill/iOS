int foo()
{
	return VALUE;
}

