
#include <stdio.h>
#include <string.h>

void barInDylib()
{
}
