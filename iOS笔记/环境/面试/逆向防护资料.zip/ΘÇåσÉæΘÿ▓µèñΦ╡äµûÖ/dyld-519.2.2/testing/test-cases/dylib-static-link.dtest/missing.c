#include <stdio.h>
#include <signal.h>

int main()
{
    printf("[BEGIN] dylib-static-link missing\n");
    printf("[FAIL] dylib-static-link missing, program should not have launched\n");

	return 0;
}


