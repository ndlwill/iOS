

#if HAS_SYMBOL
int slipperySymbol = 5;
#endif
