
void foo() { }

#if DYN
void foo2() {}
#endif
