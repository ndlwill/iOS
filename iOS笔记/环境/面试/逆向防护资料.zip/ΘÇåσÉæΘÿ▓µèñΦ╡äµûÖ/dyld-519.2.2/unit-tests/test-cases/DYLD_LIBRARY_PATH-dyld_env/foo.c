
int foo()
{
	return RESULT;
}
