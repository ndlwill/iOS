#include <stdbool.h>


bool test1()
{
	return false;
}

