# Contributing

This repository hosts the content for <https://heckj.github.io/swiftui-notes/> with code
samples, playgrounds, projects, and notes on using all of the above. It is intended as a
learning resource, and intentionally open to all.

If you'd like to see something added to the site, projects, or playgrounds then please
feel free to [fork this repository](https://github.com/heckj/swiftui-notes),
[send pull requests](https://github.com/heckj/swiftui-notes/compare?expand=1) with
content updates or fixes, or [open an issue](https://github.com/heckj/swiftui-notes/issues/new/choose)
against the content.
