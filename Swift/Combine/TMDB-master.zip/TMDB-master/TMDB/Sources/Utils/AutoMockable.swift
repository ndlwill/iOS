//
//  AutoMockable.swift
//  TMDB
//
//  Created by Maksym Shcheglov on 08/05/2020.
//  Copyright © 2020 Maksym Shcheglov. All rights reserved.
//

import Foundation

public protocol AutoMockable {}
