//
//  DeviceCell.m
//  MMLanScan
//
//  Created by Michalis Mavris on 12/08/16.
//  Copyright © 2016 Miksoft. All rights reserved.
//

#import "DeviceCell.h"

@implementation DeviceCell

@end
