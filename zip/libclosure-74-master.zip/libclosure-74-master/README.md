# libclosure-74

Compilable libclosure-74 from Apple

可编译可调试的Block开源库

I couldn't find the file which include '_platform_memmove', so I commented the macro.

由于我没有找到'_platform_memmove'的实现，所以我注释了这个宏，在运行测试过程中没有发现问题。
