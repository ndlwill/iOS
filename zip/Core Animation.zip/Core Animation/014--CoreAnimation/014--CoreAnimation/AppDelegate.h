//
//  AppDelegate.h
//  014--CoreAnimation
//
//  Created by 张小杨 on 2021/1/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

