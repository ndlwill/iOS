//
//  main.m
//  012--CoreAnimation-CAEmitterLayer
//
//  Created by 张小杨 on 2021/1/22.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
