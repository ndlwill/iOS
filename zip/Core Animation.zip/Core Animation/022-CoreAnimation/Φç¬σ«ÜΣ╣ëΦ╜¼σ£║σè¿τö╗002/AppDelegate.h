//
//  AppDelegate.h
//  自定义转场动画002
//
//  Created by 张小杨 on 2021/1/22.
//
#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

