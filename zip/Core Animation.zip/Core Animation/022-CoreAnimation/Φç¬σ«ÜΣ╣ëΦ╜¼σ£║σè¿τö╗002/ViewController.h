//
//  ViewController.h
//  自定义转场动画002
//
//  Created by 张小杨 on 2021/1/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *blackBtn;

@end

