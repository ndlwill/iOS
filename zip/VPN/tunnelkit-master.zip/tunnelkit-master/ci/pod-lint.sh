#!/bin/sh
time bundle exec pod lib lint --allow-warnings --verbose
