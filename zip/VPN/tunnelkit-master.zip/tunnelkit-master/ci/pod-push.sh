#!/bin/sh
time bundle exec pod trunk push --allow-warnings --verbose
