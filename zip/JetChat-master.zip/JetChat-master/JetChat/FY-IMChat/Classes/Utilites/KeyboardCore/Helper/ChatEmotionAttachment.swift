//
//  ChatEmotionAttachment.swift
//  FY-JetChat
//
//  Created by iOS.Jet on 2019/11/22.
//  Copyright © 2019 Jett. All rights reserved.
//

import UIKit

class ChatEmotionAttachment: NSTextAttachment {
    var text: String?
}
