//
//  FYMessageBaseModel.swift
//  FY-JetChat
//
//  Created by iOS.Jet on 2019/11/20.
//  Copyright © 2019 Jett. All rights reserved.
//

import UIKit
import WCDBSwift
import HandyJSON

class FYMessageBaseModel: NSObject, HandyJSON {
    
    required override init() { }
}
